# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['emailnotify']

package_data = \
{'': ['*']}

install_requires = \
['IMAPClient>=2.2.0,<3.0.0',
 'appdirs>=1.4.4,<2.0.0',
 'keyring>=21.5.0,<22.0.0',
 'notify-py>=0.3.1,<0.4.0']

entry_points = \
{'console_scripts': ['emailnotify = emailnotify.emailnotify:main']}

setup_kwargs = {
    'name': 'emailnotify',
    'version': '0.1.0',
    'description': 'Email notification daemon',
    'long_description': None,
    'author': 'kanashimia',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
