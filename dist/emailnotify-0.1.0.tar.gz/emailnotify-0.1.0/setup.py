# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['emailnotify']

package_data = \
{'': ['*']}

install_requires = \
['IMAPClient>=2.2.0,<3.0.0',
 'appdirs>=1.4.4,<2.0.0',
 'keyring>=21.5.0,<22.0.0',
 'notify-py>=0.3.1,<0.4.0']

entry_points = \
{'console_scripts': ['emailnotify = emailnotify.emailnotify:main']}

setup_kwargs = {
    'name': 'emailnotify',
    'version': '0.1.0',
    'description': 'Email notification daemon',
    'long_description': 'emailnotify\n===============================================================================\nemailnotify is a program, that displays email message as a push potification,\nupon its arrival, using imap idle.\n\nset password\n-------------------------------------------------------------------------------\nFirst you must prompt for password::\n\n    python -m emailnotify -p\n\nemailnotify saves password in the credential store,\nso you mush have it installed (mostly for systemd/LinuX users).\n\nrun\n-------------------------------------------------------------------------------\nThen must first configure ``readme_renderer`` either by placing config\nin the default folder, ``~/.config/emailnotify/config.ini`` on linux,\nor provide path to your config file like this::\n\n    python -m emailnotify -c PATH_TO_CONFIG\n\nDefault file structure looks like this (``folder`` field is optional)::\n\n    [mail]\n    host = imap.coolmail.com\n    username = coolguy@coolmail.com\n    folder = INBOX\n\nOn the first login you must pass ``-p`` flag to prompt for a password \ninteractively::\n\n    python -m emailnotify -p\n\nemailnotify saves password in the credential store,\nso you mush have it installed (mostly for systemd/LinuX users).\n\nAfter that can just run it as::\n\n    python -m emailnotify\n',
    'author': 'kanashimia',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/kanashimia/emailnotify',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
